import React, { useState } from "react";
import axios from "axios";
import "../components/styles/js/main_signup.js";
import "../components/styles/css/style.css";
import "../components/styles/css/style_signup.css";
import avtar from "../components/styles/images/signuplogin/loginavatar.png";
import loginimg from "../components/styles/images/signuplogin/1.svg";
import { NavLink, useHistory, Link } from "react-router-dom";
import CommonMenu from "./CommonMenu";
import Footer from "./Footer";
import swal from "sweetalert";
import PORT from './ENV';
function Login() {
    const history = useHistory();
    const [username, setUsername] = useState("");
    const [password, setPassword] = useState("");

    const loginUser = async (e) => {
        e.preventDefault();
        const res = await fetch(`http://localhost:${PORT}/login`, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
        },
        success: function (response) {
            console.log("this is response " + response);

            console.log("this is response status " + JSON.parse(response));
        },
        body: JSON.stringify({
            username,
            password,
        }),
        });
        console.log(res);
        if (res.status == 200) {
        console.log(username);
        localStorage.setItem("paradiseLogin", username);
        swal("Login Successful !!").then(() => {
            if(username === 'admin'){
                window.location ="/dashboard";
            }
            
            else if(localStorage.getItem('property')){
                const goToPage = localStorage.getItem('property');
                localStorage.removeItem('property');
                window.location = goToPage;
            }
            else{
                window.location = "/";
            }
            
        });
        } else {
        swal("Invalid credentials").then(() => {
            window.location = "/login";
        });
        }
        console.log("hiime", res.status);
        console.log(Object.keys(res));
    };
    return (
        <div>
        <div>
            <CommonMenu />
            <header
            class="page-header"
            data-background="images/slide01.jpg"
            data-stellar-background-ratio="1.15"
            >
            <div class="container">
                <h1>LOGIN</h1>
                <p>
                Make yourself feel comfortable in luxury 
                </p>
                <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="#">Start</a>
                </li>
                <li class="breadcrumb-item active" style={{color:"white"}}>
                    login
                </li>
                </ol>
            </div>
            </header>
            <center>
            <div class="form-container">
                <div class="img" data-aos="fade-right">
                <img src={loginimg} />
                </div>
                <div class="login-container">
                <form onSubmit={loginUser}>
                    <img src={avtar} class="avatar" />
                    <h2>Welcome</h2>
                    <div class="input-div one">
                    <div class="i">
                        <i class="fa fa-user"></i>
                    </div>
                    <div>
                        {/* <h5>Username</h5> */}
                        <input
                        type="text"
                        placeholder="Username"
                        class="input"
                        name="username"
                        id="username"
                        autocomplete="off"
                        value={username}
                        onChange={(e) => setUsername(e.target.value)}
                        required
                        />
                    </div>
                    </div>
                    <div class="input-div two">
                    <div class="i">
                        <i class="fa fa-lock"></i>
                    </div>
                    <div>
                        {/* <h5>Password</h5> */}
                        <input
                        type="password"
                        placeholder="Password"
                        class="input"
                        name="password"
                        id="password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        autocomplete="off"
                        required
                        />
                    </div>
                    </div>
                    <Link to="/signup">
                    <a>Don't Have Account? Sign up</a>
                    </Link>
                    <center>
                    <input type="submit" class="button" value="Login" />
                    </center>
                </form>
                </div>
            </div>
            </center>
        </div>
        <Footer />
        </div>
    );
}

export default Login;
