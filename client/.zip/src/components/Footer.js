import React from 'react';
import ReactDom from 'react-dom';

import Page1Video from './PageVideo';
// import '../App.css';
import icon1 from './styles/images/footer-icon01.png';
import icon2 from './styles/images/footer-icon02.png';
import icon3 from './styles/images/footer-icon03.png';
import logolight from './styles/images/logo-light.png';
import flagtr from './styles/images/flag-tr.svg';
import flagen from './styles/images/flag-en.svg';
import flagua from './styles/images/flag-ua.svg';
import flagbr from './styles/images/flag-br.svg';
import brand from  './styles/images/brand.png'
import '../components/styles/css/style.css';
import { Link } from 'react-router-dom';

function Footer() {
    return (
        <>
       
            <section class="footer-bar">
  <div class="container">
    <div class="inner wow fadeIn">
      <div class="row">
        <div class="col-lg-4 wow fadeInUp" data-wow-delay="0.05s">
          <figure><img src={icon1} alt="Image"/></figure>
          <h3>Address Infos</h3>
          <p>Kyiv | G. Stalingrada Avenue, 6 <br/>
            Vilnius | Antakalnio St. 17</p>
        </div>
       
        <div class="col-lg-4 wow fadeInUp" data-wow-delay="0.10s">
          <figure><img src={icon2} alt="Image"/></figure>
          <h3>Working Hours</h3>
          <p>Monday to Friday <strong>09:00</strong> to <strong>18:30</strong> <br/>
            Saturday we work until <strong>15:30</strong></p>
        </div>
        
        <div class="col-lg-4 wow fadeInUp" data-wow-delay="0.15s">
          <figure><img src={icon3} alt="Image"/></figure>
          <h3>Sales Office</h3>
          <p>Boryssa Himry 124 B Block Paradisey<br/>
            Kiev Oblast - India</p>
        </div>
        
      </div>
     
    </div>
    
  </div>
  
</section>

<footer class="footer">
  <div class="container">
    <div class="row">
      <div class="col-lg-4 wow fadeInUp" data-wow-delay="0.05s"> <img src={brand} alt="Image" style={{width:"35vh", height:"20vh"}} class="logo"/>
        <p>By aiming to take the life quality to an upper level with the whole realized Projects, paradiseliving continues to be the address of luxury.</p>
      
        
      </div>
     
      <div class="col-lg-2 col-md-6 wow fadeInUp" data-wow-delay="0.10s">
        <ul class="footer-menu">
         <Link to="/" > <li><a href="">paradiseliving</a> </li></Link>
          <li><a href="#">Apartments</a></li>
          <li><a href="#">Facilities</a></li>
          <li><a href="#">News</a></li>
          <li><a href="#">Contact</a></li>
        </ul>
      </div>
      
      <div class="col-lg-2 col-md-6 wow fadeInUp" data-wow-delay="0.15s">
        <ul class="footer-menu">
        <li><Link to="/bunglow">  <a >Bunglow</a>  </Link></li>
          <li><Link to="/rent"> <a href="#">Rent</a></Link></li>
          <li> <Link to="/pg">  <a href="#">Paying Guest</a></Link></li>
          <li><Link to="/flat"> <a href="#">Flat</a></Link></li>
        </ul>
      </div>
      
      <div class="col-lg-4 wow fadeInUp" data-wow-delay="0.20s">
        <div class="contact-box">
          <h5>CALL CENTER</h5>
          <h3>+91 5555-444-222</h3>
          <p><a href="#">support@paradiseliving.com</a></p>
          
        </div>
       
      </div>
      <div class="col-12"> <span class="copyright">© 2021 Paradise-Living | Real Estate &amp; Luxury Homes</span> <span class="creation">Site created by <a>DHAVAL & ANSHIKA</a></span> </div>
      </div>
   
  </div>
   
</footer>

        </>
    )
}

export default Footer
