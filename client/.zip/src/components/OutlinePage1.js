import React from 'react'
import plane1 from './styles/images/plan01.jpg';
import plane2 from './styles/images/plan02.jpg';
import plane3 from './styles/images/plan03.jpg';
import ib1  from './styles/images/icon-benefits01.png';
import ib2  from './styles/images/icon-benefits02.png';
import ib3  from './styles/images/icon-benefits03.png';
import ib4  from './styles/images/icon-benefits04.png';
import ib5  from './styles/images/icon-benefits05.png';
import logo1  from './styles/images/logo01.jpg';
import logo2  from './styles/images/logo02.jpg';
import logo3  from './styles/images/logo03.jpg';
import logo4  from './styles/images/logo04.jpg';
import logo5  from './styles/images/logo05.jpg';
import logo6  from './styles/images/logo06.jpg';

import si01  from './styles/images/side-image01.jpg';
import si02  from './styles/images/icon-m2.png';

import '../components/styles/css/style.css';
function OutlinePage1() {
     const clickthree = ()=>{

       
         document.getElementById("tab-three").removeAttribute('class', 'tab-pane fade show active');
         document.getElementById("tab-two").setAttribute('class', 'tab-pane fade');
         document.getElementById("tab-one").setAttribute('class', 'tab-pane fade');


     }
     const clickone =() =>{
        document.getElementById("tab-one").removeAttribute('class', 'tab-pane fade show active');
        document.getElementById("tab-two").setAttribute('class', 'tab-pane fade');
        document.getElementById("tab-three").setAttribute('class', 'tab-pane fade');
     }

     const clicktwo = () =>{
        document.getElementById("tab-two").removeAttribute('class', 'tab-pane fade show active');
        document.getElementById("tab-three").setAttribute('class', 'tab-pane fade');
        document.getElementById("tab-one").setAttribute('class', 'tab-pane fade');
     }
    return (
     
        
        <div>

<section class="intro">
  <div class="container">
    <div class="row align-items-center">
      <div class="col-lg-6">
        <figure>
          <div class="pattern-bg" data-stellar-ratio="1.07"></div>
          
          <div class="holder" data-stellar-ratio="1.10"> <img src={si01} alt="Image"/></div>
        
        </figure>
      </div>
      
      <div class="col-lg-6 wow fadeInUp">
        <div class="content-box"> 
          <h4><span>Paradisey</span> Construction LLC</h4>
          <h3>Living spaces for creative peoples</h3>
          <p>The smaller male cones release pollen, 
            which fertilizes the female </p>
          <a href="#"> <img src={si02} alt="Image"/>See our projects</a> </div>
        
      </div>
      
    </div>
  
  </div>
  
</section>
{/*  */}
<section class="logos">
  <div class="container">
    <div class="row">
      <div class="col-lg-2 col-md-4 col-sm-6 col-6 wow fadeInUp" data-wow-delay="0s">
        <figure> <img src={logo1} alt="Image"/>
          <h6>TABLE</h6>
        </figure>
      </div>
  
      <div class="col-lg-2 col-md-4 col-sm-6 col-6 wow fadeInUp" data-wow-delay="0.05s">
        <figure> <img src={logo2} alt="Image"/>
          <h6>PLANE</h6>
        </figure>
      </div>
     
      <div class="col-lg-2 col-md-4 col-sm-6 col-6 wow fadeInUp" data-wow-delay="0.10s">
        <figure> <img src={logo3} alt="Image"/>
          <h6>CONNECT</h6>
        </figure>
      </div>
   
      <div class="col-lg-2 col-md-4 col-sm-6 col-6 wow fadeInUp" data-wow-delay="0.15s">
        <figure> <img src={logo4} alt="Image"/>
          <h6>GLASSES</h6>
        </figure>
      </div>
      
      <div class="col-lg-2 col-md-4 col-sm-6 col-6 wow fadeInUp" data-wow-delay="0.20s">
        <figure> <img src={logo5} alt="Image"/>
          <h6>PIXEL</h6>
        </figure>
      </div>
    
      <div class="col-lg-2 col-md-4 col-sm-6 col-6 wow fadeInUp" data-wow-delay="0.25s">
        <figure> <img src={logo6} alt="Image"/>
          <h6>ATTACH</h6>
        </figure>
      </div>
      
    </div>
   
  </div>
  
</section>
        {/* hover text */}
<section class="benefits">
  <div class="container">
    <div class="row">
      <div class="col-12 wow fadeInUp"> 
        <h4><span>paradiseliving</span> Property</h4>
        <h3>Decorated Flats in Paradise- Kiev</h3>
      </div>
  
      <div class="col wow fadeInUp" data-wow-delay="0s">
        <figure> <img src={ib1} alt="Image"/> <b></b> </figure>
        <h6>Near to Subway</h6>
        <span class="odometer" data-count="28" data-status="yes">28</span> <span class="extra">min</span> </div>
     
      <div class="col wow fadeInUp" data-wow-delay="0.05s">
        <figure> <img src={ib2} alt="Image"/> <b></b> </figure>
        <h6>Spaces in Paradisey</h6>
        <span class="odometer" data-count="32" data-status="yes">32</span> <span class="extra">+</span> </div>
    
      <div class="col wow fadeInUp" data-wow-delay="0.10s">
        <figure> <img src={ib3} alt="Image"/> <b></b> </figure>
        <h6>Spaces in Paradisey</h6>
        <span class="odometer" data-count="15" data-status="yes">15</span> <span class="extra">%</span> </div>
      
      <div class="col wow fadeInUp" data-wow-delay="0.15s">
        <figure> <img src={ib4} alt="Image"/> <b></b> </figure>
        <h6>Spaces in Paradisey</h6>
        <span class="odometer" data-count="3" data-status="yes">3</span> <span class="extra">years</span> </div>
     
      <div class="col wow fadeInUp" data-wow-delay="0.20s">
        <figure> <img src={ib5} alt="Image"/> <b></b> </figure>
        <h6>Spaces in Paradisey</h6>
        <span class="odometer" data-count="79" data-status="yes">79</span> <span class="extra">m²</span> </div>
      
    </div>
    
  </div>
 
</section>
            {/* end hover block */}
            <section class="property-plans">
  <div class="container">
    <div class="row align-items-center">
      <div class="col-lg-6 wow fadeInUp"> 
        <h4><span>paradiseliving</span> Living Spaces</h4>
        <h3>Decorated Flats in Paradise- Kiev</h3>
        <p>We are waiting for you in our sales office for having all these opportunities with affordable prices and appropriate payment opportunities..</p>
        <table>
          <tbody>
            <tr>
              <td>Total area:</td>
              <td>680 metre square</td>
            </tr>
            <tr>
              <td>Total Floor:</td>
              <td>24 Floor</td>
            </tr>
            <tr>
              <td>Parking Lot:</td>
              <td>5 Large</td>
            </tr>
            <tr>
              <td>Social Area:</td>
              <td>860 m²</td>
            </tr>
          </tbody>
        </table>
      </div>
    
      <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.05s">
       
        <ul class="nav nav-pills" id="pills-tab" role="tablist">
          <li class="nav-item"> <a class="nav-link active" data-toggle="pill" href="#tab-one" onClick={()=>clickone()}>1 Room 47m²</a> </li>
          <li class="nav-item"> <a class="nav-link" data-toggle="pill" href="#tab-two" role="tab" onClick={()=>clicktwo()}>2 Rooms 65m²</a> </li>
          <li class="nav-item"> <a class="nav-link" data-toggle="pill" href="#tab-three" role="tab" onClick={()=>clickthree()}>3 Rooms 90m²</a> </li>
        </ul>
        <div class="tab-content">
          <div class="tab-pane fade show active" id="tab-one">
            <figure><img src={plane1} alt="Image"/></figure>
          </div>
         
          <div class="tab-pane fade " id="tab-two">
            <figure><img src={plane2} alt="Image"/></figure>
          </div>
        
          <div class="tab-pane fade " id="tab-three">
            <figure><img src={plane3} alt="Image"/></figure>
          </div>
          
        </div>
        
      </div>
      
    </div>
    
  </div>
  
</section>
        </div>
    )
}

export default OutlinePage1
