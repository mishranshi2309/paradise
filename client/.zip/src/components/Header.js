import React, { useEffect ,useState} from 'react'
import slide01  from './styles/images/slide01.jpg';
import slide02  from './styles/images/slide02.jpg';
import slide03  from './styles/images/slide03.jpg';
import {Link} from 'react-router-dom';
import serv01 from './styles/images/services-icon01.png';
import serv02 from './styles/images/services-icon02.png';
import serv07 from './styles/images/services-icon07.png';
import logolight from './styles/images/logo-light.png';
import logophone from './styles/images/icon-phone.png';
import gthumbnail01 from './styles/images/gallery-thumb01.jpg';
import gthumbnail02 from './styles/images/gallery-thumb02.jpg';
import gthumbnail03 from './styles/images/gallery-thumb03.jpg';
import brand from  './styles/images/brand.png'

import '../components/styles/css/style.css';
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import Slider from "react-slick";
function Header() {

  
  const [user, setUser]=useState();
  
  useEffect(
    ()=>{
      const value = localStorage.getItem("paradiseLogin");
      setUser(value);
    },[]
  )
  const renderSlides = () =>
    [slide01, slide02, slide03].map(num => (
      <div style={{backgroundImage: `url(${num})`}}>
        <img src={num} style={{"height":"100%", "width":"100%"}}/>
      </div>
    ));
    return (
        <div>
          <div>
            <nav class="navbar">
              <div class="container" >
                <div class="upper-side" style={{marginTop:"20px"}}>
                  <div class="logo"> <a ><img src={brand} alt="Image" style={{width:"26vh",height: "20vh",position:"absolute",marginTop:"-34px"}}/></a> </div>
                  <div class="phone-email"> <img src={logophone} alt="Image"/>
                    <h4>+91 5555-444-222</h4>
                    <small><a href="#">support@paradiseliving.com</a></small> </div>
                  <div class="language"> <a href="#">EN</a> <a href="#">UA</a> </div>
                
                  <div class="language" style={{color:"white"}}>
                    
                    {/* <Link to="/login"><a href="#">LOGIN</a></Link> |<Link to="/signup"> <a> SIGNUP</a> </Link>  */}
                    {user?user: <p> <Link to="/login"><a href="#">LOGIN</a></Link> |<Link to="/signup"> <a> SIGNUP</a> </Link> </p>}</div>
                </div>
                <div class="menu" style={{marginTop: "-2vh"}}> 
                  <ul>
                  <Link to="/"> <li><a href="/">HOME</a></li></Link>
                    <li><a href="#">PROPERTY</a>
                      <ul>
                      <li><Link to="/bunglow">  <a >Bunglow</a>  </Link></li>
                      <li><Link to="/rent"> <a href="#">Rent</a></Link></li>
                      <li> <Link to="/pg">  <a href="#">Paying Guest</a></Link></li>
                      <li><Link to="/flat"> <a href="#">Flat</a></Link></li>
                      </ul>
                    </li>
                    <Link to="/about"><li><a href="#">CONTACT</a>
                    </li></Link>
                    <Link to="/blog"><li><a href="#">BLOG</a></li></Link>
                    <Link to="/facilities"><li><a href="facilities.html">FACILITIES</a></li></Link>
                    {user? <Link to="/logout"><li><a href="#">LOGOUT</a></li> </Link>:''}
                  </ul>
                </div>
              </div>
            </nav>
          </div>
          <div style={{ width:"100%", marginBottom:50,marginTop:-210}}>
              <Slider dots={true}
              infinite={true}
              arrows={true}
            slidesToShow={1}
            slidesToScroll={1}
            focusOnSelect={true}
            autoplay={true}
            autoplaySpeed={2000}>{renderSlides()}</Slider>
          </div>
        </div>
  )
}

export default Header
