import React,{useState} from 'react'
import './assets/css/form.css';
import PORT from "../ENV";
import axios from 'axios';
function Addproperty() {
    const [fileText, setFileText] = useState('');
    const [details, setDetails] = useState({
        fileName:null,
        area: "",
        address: "",
        costpersq: "" ,
        city: "",
        district: "",
        state: "",
        info: "",
        status: "",
        cate: "",
        agentmail:"",
        sellerName:"",
        extrafacility:"",
        houseFacing:"",
        floor:"",
        bhk:"",
        contactNumber:""
        })
    const handleChange = (e) =>{
            
      let name = e.target.name;
      let value = e.target.value;
      details[name] = value;
      setDetails(details);
      details.fileName = fileText;
        console.log(details)
      }

      const handleSubmit = ()=>{
          console.log("going to submit---");
        var fd = new FormData();
        fd.append("fileName", details.fileName);
        fd.append("area", details.area);
        fd.append("address", details.address);
        fd.append("costpersq", details.costpersq);
        fd.append("city", details.city);
        fd.append("district", details.district);
        fd.append("state", details.state);
        fd.append("cate", details.cate);
        fd.append("agentmail", details.agentmail);
        fd.append("sellerName", details.sellerName);
        fd.append("extrafacility", details.extrafacility);
        fd.append("houseFacing", details.houseFacing);
        fd.append("floor", details.floor);
        fd.append("bhk", details.bhk);
        fd.append("contactNumber", details.contactNumber);
        axios.post(`http://localhost:${PORT}/uploadfile`, fd)
        .then(res=>{
            console.log("successfully added", res); 
            
        });
      }

      const handleFile = (e) =>{
        console.log(e.target.files[0] );
        let newfile = e.target.files[0] ;
        setFileText(e.target.files[0]);
      }
    return (
        <div>
            <div className="container-fluid">
                {/* <h1 className="h3 mb-2 text-gray-800">Tables</h1> */}
                <div className="card shadow mb-4">
                    <div className="card-header py-3">
                        <h6 className="m-0 font-weight-bold text-primary">Property Details</h6>
                    </div>
                    <div className="card-body">
                        <div>
                            <form style={{width:"100%"}} onSubmit={()=>{handleSubmit()}}>
                            <div className="row">
                                <div className="col-6">
                                    <div className="form-group">
                                        <label>Category</label>
                                        <select className="form-control item" name="cate" onChange={handleChange}>
                                            <option>Select</option>
                                            <option value="Bunglow">Bunglow</option>
                                            <option value="Rent">Rent</option>
                                            <option value="Pg">Paying guest</option>
                                            <option value="Flats">Flats</option>
                                           
                                        </select>
                                    </div>
                                    
                                    <div className="form-group">
                                        <label>Cost per Square</label>
                                        <input type="number" className="form-control item" name="costpersq" onChange={handleChange} placeholder="Enter Amount "/>
                                    </div>
                                    
                                    <div className="form-group">
                                    <label>Floor</label>
                                        <input type="number" className="form-control item" name="floor"  onChange={handleChange} placeholder="Enter floor.."/>
                                    </div>
                                    
                                    <div className="form-group">
                                    <label>BHK</label>
                                        <input type="text" className="form-control item" name="bhk" onChange={handleChange} placeholder="Ex: 3BHK"/>
                                    </div>
                                    
                                    <div className="form-group">
                                    <label>Adress</label>
                                        <input type="text" className="form-control item" name="address" onChange={handleChange} placeholder="Location..."/>
                                    </div>
                                    
                                    <div className="form-group">
                                    <label>City</label>
                                        <input type="text" className="form-control item" name="city" onChange={handleChange} placeholder="Enter your City"/>
                                    </div>
                                    
                                    <div className="form-group">
                                    <label>District</label>
                                        <input type="text" className="form-control item" name="district" onChange={handleChange} placeholder="Enter district"/>
                                    </div>
                                    
                                    <div className="form-group">
                                    <label>Area</label>
                                        <input type="number" className="form-control item" name="area" onChange={handleChange} placeholder="Enter Area"/>
                                    </div>
                                </div>
                                <div className="col-6">
                                <div className="form-group">
                                    <label>State</label>
                                        <input type="text" className="form-control item" name="state" onChange={handleChange} placeholder="Enter State"/>
                                    </div>
                                    
                                    <div className="form-group">
                                    <label>Info</label>
                                        <input type="text" className="form-control item" name="info" onChange={handleChange} placeholder="Information"/>
                                    </div>
                                    
                                    <div className="form-group">
                                    <label>Status</label>
                                        <input type="text" className="form-control item" name="status" onChange={handleChange} placeholder="Proprty current status"/>
                                    </div>
                                    
                                    <div className="form-group">
                                    <label>Mobile No.</label>
                                        <input type="text" className="form-control item" name="contactNumber" onChange={handleChange} placeholder="Enter contact number"/>
                                    </div>
                                    
                                    <div className="form-group">
                                    <label>Housefacing</label>
                                        <input type="text" className="form-control item" name="houseFacing" onChange={handleChange} placeholder="House facing "/>
                                    </div>
                                    
                                    <div className="form-group">
                                    <label>Extra</label>
                                        <input type="text" className="form-control item" name="extrafacility" onChange={handleChange} placeholder="enter extra facilities..."/>
                                    </div>
                                    
                                    <div className="form-group">
                                    <label>Sellername</label>
                                        <input type="text" className="form-control item" name="sellerName" onChange={handleChange} placeholder="Enter your name"/>
                                    </div>
                                </div>
                                <div className="col-6 mb-4">
                                <div className="form-group">
                                    <label>Upload Property Images</label>
                                    <div class="form-group">
                                        <div >
                                            <input type="file" class="form-control" id="file" name="fileName"  onChange={handleFile} />
                                            {/* <label class="custom-file-label" for="inputGroupFile04">Choose file</label> */}
                                        </div>
                                    </div>
                                    </div>
                                    <div className="form-group">
                                    <label>Agent Mail</label>
                                    <div class="input-group">
                                    <input type="text" className="form-control item" name="agentmail"  onChange={handleChange} placeholder="Enter Agent Email"/>

                                    </div>
                                    </div>
                                </div>
                                <div className="col-12 mt-1">
                                    <div className="form-group">
                                        <button type="submit" className="btn btn-block btn-primary create-account">Add Property</button>
                                       
                                    </div>
                                </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Addproperty