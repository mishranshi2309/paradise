import React,{useState, useEffect} from 'react'
import axios from 'axios'
import {Table} from 'react-bootstrap';
import { decompress } from 'lz-string'
import PORT from "../ENV";
import './assets/vendor/fontawesome-free/css/all.min.css';
import './assets/css/sb-admin-2.min.css';
import './assets/css/table.css';
import Sort from './Sort';
import './assets/vendor/datatables/dataTables.bootstrap4.min.css';
import {Modal, Button, Form} from 'react-bootstrap';


function Propertydetails() {
  const [isEdit, setIsEdit] = useState(false);
  const [fileText, setFileText] = useState('');

  const [show, setShow] = useState(false);
  const [index, setIndex] = useState('');
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

    const [todoProp , setTodoProp] = useState(0)
    const handleProp = () =>{
      var request = new XMLHttpRequest();
        request.onreadystatechange = function () {
          if (request.readyState == 4 && request.status == 200) {
            const response = JSON.parse(request.response);
            setTodoProp(response);
          }
        };
        request.open("GET", `http://localhost:${PORT}/allproperty`, true);
        request.send();
    }
    useEffect(() => {
        handleProp()
      }, []);
    
      useEffect(() => {
        
        console.log(todoProp);
      }, [todoProp]);
     console.log("-->",todoProp);

     const handleDelete =(ele,id)=>{
       console.log(id);
      axios.get(`http://localhost:${PORT}/property/${id}`)
      .then(res=>{
        handleProp()
          // window.location='/';
      })
     }
     const handleEdit = (ele, id)=>{
      setIsEdit(true);
      setIndex(id);
      handleShow();
      console.log(id);
      setDetails(ele)
      console.log(details);
     }
     const handleEditing = () =>{

     }
     const [typeSort, setTypeSort] = useState(1);

     const handleSort = (x) => {
      setTypeSort(!typeSort);
      console.log(Sort.dynamicSort(x, todoProp, typeSort));
    };

    const [details, setDetails] = useState({
    fileName:"",
    area: "",
    address: "",
    costpersq: "",
    city: "",
    district: "",
    state: "",
    info: "",
    status: "",
    cate: "",
    agentmail:"",
    extrafacility:"",
    houseFacing:"",
    floor:"",
    bhk:"",
    contactNumber:""
    })
    const handleChange = (e) =>{
      const c = { ...details };
    let name = e.target.name;
    let value = e.target.value;
    c[name] = value;
    setDetails(c);
      console.log(details);
    }
  
    const handleDetailSubmit=()=>{
      console.log("going to submit---");
      var fd = new FormData();
      fd.append("fileName", details.fileName);
      fd.append("area", details.area);
      fd.append("address", details.address);
      fd.append("costpersq", details.costpersq);
      fd.append("city", details.city);
      fd.append("district", details.district);
      fd.append("state", details.state);
      fd.append("status", details.status);
      fd.append("info", details.info);
      fd.append("cate", details.cate);
      fd.append("agentmail", details.agentmail);
      fd.append("sellerName", details.sellerName);
      fd.append("extrafacility", details.extrafacility);
      fd.append("houseFacing", details.houseFacing);
      fd.append("floor", details.floor);
      fd.append("bhk", details.bhk);
      fd.append("contactNumber", details.contactNumber);
      axios.post(`http://localhost:${PORT}/editFile/${index}`, fd)
      .then(res=>{
          console.log("successfully added", res); 
          
      });
    }

    const handleFile = (e) =>{

        
      console.log(e.target.files[0] );
      let newfile = e.target.files[0] ;
      setFileText(e.target.files[0]);
  
    }
    const [fileData , setFileData] = useState();
    const fetchFile =(fileAddr) =>{
      let list = `F://Desktop backup//Project//paradiseliving//server//uploads//${fileAddr}`;

      console.log(fileAddr);
      // axios.get(`http://localhost:${PORT}/getFileData/${fileAddr}`).then(res=>{
      //   setFileData(res.data);
      // })
      return list;
    }

    return (
        <div>
          <Modal show={show} >
        <Modal.Header >
          <Modal.Title>Send Invite</Modal.Title>
        </Modal.Header>
        <Modal.Body>
        <form  style={{width:"100%"}} onSubmit={handleDetailSubmit}>
                            <div className="row">
                           
                                <div className="col-6">
                                    <div className="form-group">
                                        <label>Category</label>
                                        <select className="form-control item" name="category" onChange={handleChange}>
                                            <option>Select</option>
                                            <option>Bunglow</option>
                                            <option>Rent</option>
                                            <option>Pain guest</option>
                                            <option>Flats</option>
                                            <option>Farm house</option>
                                        </select>
                                    </div>
                                    
                                    <div className="form-group">
                                        <label>Cost per Square</label>
                                        <input type="text" className="form-control item" name="costpersq" placeholder="Enter Amount " value={details.costpersq}  onChange={handleChange}/>
                                    </div>
                                    
                                    <div className="form-group">
                                    <label>Floor</label>
                                        <input type="text" className="form-control item" name="floor" placeholder="Enter floor.." value={details.floor} onChange={handleChange}/>
                                    </div>
                                    
                                    <div className="form-group">
                                    <label>BHK</label>
                                        <input type="text" className="form-control item" name="bhk" placeholder="Ex: 3BHK" value={details.bhk} onChange={handleChange}/>
                                    </div>
                                    
                                    <div className="form-group">
                                    <label>Adress</label>
                                        <input type="text" className="form-control item" name="address" placeholder="Location..." value={details.address}  onChange={handleChange}/>
                                    </div>
                                    
                                    <div className="form-group">
                                    <label>City</label>
                                        <input type="text" className="form-control item" name="city" placeholder="Enter your City" value={details.city}  onChange={handleChange}/>
                                    </div>
                                    
                                    <div className="form-group">
                                    <label>District</label>
                                        <input type="text" className="form-control item" name="district" placeholder="Enter district" value={details.district} onChange={handleChange}/>
                                    </div>
                                    <div className="form-group">
                                    <label>Area</label>
                                        <input type="number" className="form-control item" name="area" placeholder="Enter area" value={details.area} onChange={handleChange} placeholder="Enter Area"/>
                                    </div>
                                </div>
                                <div className="col-6">
                                <div className="form-group">
                                    <label>State</label>
                                        <input type="text" className="form-control item" name="state" placeholder="Enter State" value={details.state} onChange={handleChange}/>
                                    </div>
                                    
                                    <div className="form-group">
                                    <label>Info</label>
                                        <input type="text" className="form-control item" name="info" placeholder="Information" value={details.info} onChange={handleChange}/>
                                    </div>
                                    
                                    <div className="form-group">
                                    <label>Status</label>
                                        <input type="text" className="form-control item" name="status" placeholder="Property current status" value={details.status} onChange={handleChange}/>
                                    </div>
                                    
                                    <div className="form-group">
                                    <label>Mobile No.</label>
                                        <input type="text" className="form-control item" name="contactNumber" placeholder="Enter contact number" value={details.contactNumber} onChange={handleChange}/>
                                    </div>
                                    
                                    <div className="form-group">
                                    <label>Housefacing</label>
                                        <input type="text" className="form-control item" name="houseFacing" placeholder="House facing "  value={details.houseFacing} onChange={handleChange}/>
                                    </div>
                                    
                                    <div className="form-group">
                                    <label>Extra</label>
                                        <input type="text" className="form-control item" name="extrafacility" placeholder="enter extra facilities..." value={details.extafacility} onChange={handleChange}/>
                                    </div>
                                    
                                    <div className="form-group">
                                    <label>Sellername</label>
                                        <input type="text" className="form-control item" name="sellerName" placeholder="Enter your name" value={details.sellerName} onChange={handleChange}/>
                                    </div>
                                </div>
                                <div className="col-12 mb-4">
                                    <label>Upload Property Images</label>
                                    <div class="input-group">
                                        <div class="custom-file">
                                            <input type="file" class="form-control" id="file" name="fileName"  onChange={handleFile} />
                                        </div>
                                    </div>
                                </div>
                              
                                <div className="col-12 mt-1">
                                    <div className="form-group">
                                     <button type="submit" className="btn btn-block btn-primary create-account">Save Property</button>
                                       
                                    </div>
                                    <div className="form-group">
                                        <button type="button" className="btn btn-block btn-warning create-account" onClick={()=>handleClose()}>Cancel</button>
                                       
                                    </div>
                                </div>
                                </div>
                            </form>
                            </Modal.Body>
                        
      </Modal>
             <div class="container-fluid">
                {/* <h1 class="h3 mb-2 text-gray-800">Tables</h1> */}
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">Property List</h6>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                         <Table class="table table-bordered" id="dataTable" width="100%">
                                <thead style={{ position: "sticky",top:"0"}}>
                                        
                                    <tr >
                                        <th>Sno</th>
                                      {todoProp && Object.keys(todoProp[0]).map((ele, index)=>(
                                          <th key={index} onClick={() => handleSort(ele)}>{(ele !== "_id" && ele!="__v")?ele:''}</th>
                                      ))}
                                       
                                       <th>Action</th>
                                    </tr>
                                </thead>
                               
                                <tbody>
                                    
                                        {
                                            todoProp && todoProp.map((element, index) => (
                                                <tr key={index} className="my-2" style={{overflow:"scroll"}}>
                                                  <td>{index + 1}</td>
                                                  {Object.keys(element).map((ele, i) => (
                                                    <td key={index + i + "td"}>{(ele !== "_id" && ele!="__v")?(ele == 'fileName')?<div ><img className="property-tag" src={"uploads/"+element[ele]} /></div>:element[ele]:null}</td>
                                                  ))}
                                                  <td className="d-flex justify-content-center">
                                                    <div
                                                      type="button"
                                                      className="success"
                                                      onClick={() => handleDelete(element,element._id)}
                                                    >
                                                      <img
                                                        alt="del"
                                                        src="https://img.icons8.com/material-sharp/30/000000/delete-forever.png"
                                                      />
                                                    </div>
                                                    <div
                                                      type="button"
                                                      className=""
                                                      onClick={() => handleEdit(element, element._id)}
                                                    >
                                                      <img
                                                        alt="edit"
                                                        src="https://img.icons8.com/material-outlined/30/000000/edit-file--v1.png"
                                                      />
                                                    </div>
                                                  </td>
                                                </tr>
                                              ))
                                        }
                                        
                                    
                                </tbody>
                            </Table> 

                                
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Propertydetails
