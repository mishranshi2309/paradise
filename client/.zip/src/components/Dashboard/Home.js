import React, { useState, useEffect } from "react";
import { NavLink, useHistory, Link , Redirect} from "react-router-dom";
// import axios from "axios";
import "../styles/js/main_signup.js";
import "../styles/css/style.css";
import "../styles/css/style_property.css";
import "../styles/css/style_signup.css";
import DashboardMenu from "./DashboardMenu";
 import Footer from "./Footer"
// import swal from "sweetalert";   
// import PropertyDetail from "../PropertyDetail";
// import PORT from "../ENV";
import slide02  from '../styles/images/slide02.jpg';
import Propertylist from "./Propertylist";
import Dashboard from "./Dashboard";
import Customerlist from "./Customerlist.js";
import Agentlist from "./Agentlist.js";
import Requestlist from "./Requestlist.js";
import Addproperty from "./Addproperty.js";
import axios from "axios";
import PORT from "../ENV";

function Home() {
    
    const [menu ,setmenu] =useState("Dashboard");
    
    return (
        <div>
             <DashboardMenu />

            <header class="page-header" style={{height:"400px"}} data-background={slide02} data-stellar-background-ratio="1.15">
                <div class="container">
                    <h1>DASHBOARD</h1>
                </div>
            </header>
            <div className="container-fluid m-4 shadow-rounded">
                <div className="row" style={{height:"750px"}}>
                    <div className="col-2">
                        <div>
                            <ul className="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar" style={{position:"absolute"}}>
                                <span className="sidebar-brand d-flex align-items-center justify-content-center" href="index.html">
                                    <div className="sidebar-brand-icon">
                                        <i className="fas fa-user"></i>
                                    </div>
                                    <div className="sidebar-brand-text mx-3">Admin</div>
                                </span>
                            
                                
                                <hr className="sidebar-divider my-0"/>
                                <li className="nav-item">
                                    <span className="nav-link">
                                        <i className="fas fa-fw fa-tachometer-alt"></i>
                                        <span onClick={()=> setmenu("Dashboard")}>Dashboard</span>
                                    </span>
                                </li>
                                <li className="nav-item">
                                    <span className="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseone"
                                        aria-expanded="true" aria-controls="collapseone">
                                        <i className="fas fa-fw fa-user"></i>
                                        <span>Property</span>
                                    </span>
                                
                                    <div id="collapseone" className="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                                        <div className="bg-white py-2 collapse-inner rounded">
                                           
                                            <span className="collapse-item" onClick={()=> setmenu("Proprtylist")} >Property List</span>
                                            <span className="collapse-item" onClick={()=> setmenu("Addproprty")} >Add property</span>
                                        </div>
                                        </div>
                                    
                                </li>

                                <li className="nav-item">
                                    <span className="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo"
                                        aria-expanded="true" aria-controls="collapseTwo">
                                        <i className="fas fa-fw fa-user"></i>
                                        <span>Agent</span>
                                    </span>
                                    <div id="collapseTwo" className="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                                        <div className="bg-white py-2 collapse-inner rounded">
                                            
                                            <span className="collapse-item" onClick={()=> setmenu("Agentlist")}>Agent List</span>
                                           
                                        </div>
                                    </div>
                                </li>
                                <li className="nav-item">
                                    <span className="nav-link collapsed"  data-toggle="collapse" data-target="#collapseThree"
                                        aria-expanded="true" aria-controls="collapseThree">
                                        <i className="fas fa-fw fa-user"></i>
                                        <span>Client</span>
                                    </span>
                                    <div id="collapseThree" className="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                                        <div className="bg-white py-2 collapse-inner rounded">
                                           
                                            <span className="collapse-item" onClick={()=> setmenu("Clientlist")}>Client List</span>
                                           
                                        </div>
                                    </div>
                                </li>
                                <li className="nav-item">
                                <span className="nav-link">
                                        <i className="fas fa-fw fa-book"></i>
                                        <span  onClick={()=> setmenu("Requestlist")}>Request list</span>
                                    </span>
                                </li>
                                <li className="nav-item">
                                 <span className="nav-link">
                                        <i className="fas fa-fw fa-login"></i>
                                        
                                        <span onClick={()=>{
              localStorage.removeItem('paradiseLogin');
              window.location="/"
            }}>Logout</span>
                                    </span>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div className="col-10" style={{height:"750px", overflow:"scroll"}}>
                        {menu === "Dashboard" && <Dashboard/>}
                        {menu === "Proprtylist" && <Propertylist/>}
                        {menu === "Addproprty" && <Addproperty/>}
                        {menu === "Agentlist" && <Agentlist/>}
                        {menu === "Clientlist" && <Customerlist/>}
                        {menu === "Requestlist" && <Requestlist/>}
                    </div>
                </div>
            </div>
            <Footer/>
        </div>
    )
}

export default Home
