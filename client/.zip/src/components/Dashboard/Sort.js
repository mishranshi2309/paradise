class Sort {
  dynamicSort(property, head, typeSort) {
    console.log("typeSort", typeSort);
    head.sort((a, b) => {
      let fa = a[property.trim()].toLowerCase(),
        fb = b[property.trim()].toLowerCase();
      if (typeSort == 1) {
        if (fa < fb) {
          return -1;
        }
        if (fa > fb) {
          return 1;
        }
        return 0;
      } else if (typeSort == 0) {
        if (fa > fb) {
          return -1;
        }
        if (fa < fb) {
          return 1;
        }
        return 0;
      }
      return head;
    });

    console.log(head);
  }
}
export default new Sort();
