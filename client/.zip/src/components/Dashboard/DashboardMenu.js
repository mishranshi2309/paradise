import React,{useEffect, useState} from 'react'

import slide01  from '../styles/images/slide01.jpg';
import slide02  from '../styles/images/slide02.jpg';
import slide03  from '../styles/images/slide03.jpg';
import {Link} from 'react-router-dom';
import serv01 from '../styles/images/services-icon01.png';
import serv02 from '../styles/images/services-icon02.png';
import serv07 from '../styles/images/services-icon07.png';
import logolight from '../styles/images/logo-light.png';
import logophone from '../styles/images/icon-phone.png';
import gthumbnail01 from '../styles/images/gallery-thumb01.jpg';
import gthumbnail02 from '../styles/images/gallery-thumb02.jpg';
import gthumbnail03 from '../styles/images/gallery-thumb03.jpg';
import brand from  '../styles/images/brand.png'

import '../styles/css/style.css';
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import Slider from "react-slick";
function DashboardMenu() {
  const [user, setUser]=useState();
  
  useEffect(
    ()=>{
      const value = localStorage.getItem("paradiseLogin");
      setUser(value);
    },[]
  )
    return (
        <div>
          <nav className="navbar" style={{backgroundColor: "#13162B",height:"25vh"}}>
          <div className="container" >
              <div className="upper-side" style={{borderBottom:"none"}}>
                <div className="logo"> <a ><img src={brand} style={{width:"22vh",height: "17vh",position:"absolute",marginTop:"-44px"}} alt="Image"/></a> </div>
                <div className="phone-email"> <img src={logophone} alt="Image"/>
                  <h4>+91 5555-444-222</h4>
                  <small><a href="#">support@paradiseliving.com</a></small> </div>
                <div className="language"> <a href="#">EN</a> <a href="#">UA</a> </div>
              
                <div className="language" style={{color:'white'}}>
                  {user?user: <p> <Link to="/login"><a href="#">LOGIN</a></Link> |<Link to="/signup"> <a> SIGNUP</a> </Link> </p>}</div>
              </div>
              <div className="menu" > 
                {/* <ul>
                <Link to="/dashboard"> <li><a href="/">HOME</a></li></Link>
                  <li><a href="#">PROPERTY</a>
                  
                  </li>
                  <Link to="/customer"><li><a href="#">Customer</a>
                  </li></Link>
                  <Link to="/blog"><li><a href="#">Agent</a></li></Link>
                  <Link to="/facilities"><li><a href="facilities.html">Requests</a></li></Link>
                  {user? <Link to="/logout"><li><a href="#">LOGOUT</a></li> </Link>:''}
                </ul> */}
              </div>
            </div>        
          </nav>
          </div>
        
    )
}

export default DashboardMenu
