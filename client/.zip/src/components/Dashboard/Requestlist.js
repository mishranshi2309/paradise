import Reac, { useState, useEffect } from "react";
import axios from "axios";
import { Table } from "react-bootstrap";
import PORT from "../ENV";
import "./assets/vendor/fontawesome-free/css/all.min.css";
import "./assets/css/sb-admin-2.min.css";
import "./assets/css/table.css";
import "./assets/vendor/datatables/dataTables.bootstrap4.min.css";
import Sort from './Sort';
function Requestlist() {
  const [todoProp, setTodoProp] = useState(0);
  useEffect(() => {
    var request = new XMLHttpRequest();
    request.onreadystatechange = function () {
      if (request.readyState == 4 && request.status == 200) {
        const response = JSON.parse(request.response);
        setTodoProp(response);
      }
    };
    request.open("GET", `http://localhost:${PORT}/requestlist`, true);
    request.send();
  }, []);

  useEffect(() => {
    console.log(todoProp);
  }, [todoProp]);
  console.log("-->", todoProp);

  const [typeSort, setTypeSort] = useState(1);

  const handleSort = (x) => {
   setTypeSort(!typeSort);
   console.log(Sort.dynamicSort(x, todoProp, typeSort));
 };

  return (
    <div>
      <div class="container-fluid">
        {/* <h1 class="h3 mb-2 text-gray-800">Tables</h1> */}
        <div class="card shadow mb-4">
          <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Request List</h6>
          </div>
          <div class="card-body">
            <div class="table-responsive">
              <Table class="table table-bordered" id="dataTable" width="100%">
                <thead style={{ position: "sticky", top: "0" }}>
                  <tr>
                    <th>Sno</th>
                    {todoProp &&
                      Object.keys(todoProp[0]).map((ele, index) => (
                        <th key={index}  onClick={() => handleSort(ele)}>{(ele !== "_id" && ele!="__v") ? ele : ""}</th>
                      ))}
                  </tr>
                </thead>

                <tbody>
                  {todoProp &&
                    todoProp.map((element, index) => (
                      <tr
                        key={index}
                        className="my-2"
                        style={{ overflow: "scroll" }}
                      >
                        <td>{index + 1}</td>
                        {Object.keys(element).map((ele, i) => (
                          <td key={index + i + "td"}>
                            {(ele != "_id" && ele!="__v" )? element[ele] : null}
                          </td>
                        ))}
                      </tr>
                    ))}
                </tbody>
              </Table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Requestlist;
