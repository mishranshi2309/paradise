import React from 'react'
import axios from 'axios'
class Logindetails extends React.Component {
    state={
        students :[]
    }
    getstudents = () =>{
        axios.get('http://localhost:5003/login')
        .then(res=>{ 
            this.setState({students: res.data});
        })
    }
    componentDidMount  = ()=>{
          this.getstudents();  
    }    
    render(){
    return (
        <div>
            {
                this.state.students.map(student=>(
                    <div>
                        <p>{student.username}</p>
                        <p>{student.password}</p>
                    </div>
                ))
            }
        </div>
    )
    }
}

export default Logindetails
