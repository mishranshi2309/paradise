import React from 'react'
import ReactDom from 'react-dom';
import OutlinePage1 from './OutlinePage1';
import Header from './Header';

import icon1 from './styles/images/services-icon01.png';
import icon2 from './styles/images/services-icon02.png';
import icon3 from './styles/images/services-icon03.png';
import icon4 from './styles/images/services-icon04.png';
import icon5 from './styles/images/services-icon05.png';
import icon6 from './styles/images/services-icon06.png';
import icon7 from './styles/images/services-icon07.png';
import icon8 from './styles/images/services-icon08.png';
import icon9 from './styles/images/services-icon09.png';
import icon10 from './styles/images/services-icon10.png';
import icon11 from './styles/images/services-icon11.png';
import icon12 from './styles/images/services-icon12.png';
import rnew01 from './styles/images/recent-news01.jpg';
import rnew02 from './styles/images/recent-news02.jpg';
import rnew03 from './styles/images/recent-news03.jpg';
import Footer from './Footer';
import bg1 from './styles/images/section-bg01.jpg';
import video1 from './styles/videos/video01.mp4';
import '../components/styles/css/style.css';
function PageVideo() {
    return (
        <div>
          <Header/>
          <OutlinePage1/>
        <section class="get-consultation" data-background={bg1} data-stellar-background-ratio="0.5">
         
  <div class="container">
    <div class="row">
      <div class="col-lg-6 col-md-8 fadeInUp wow">
        <div class="content-box"> 
          <h4><span>paradiseliving</span> Living Spaces</h4>
          <h3>Are you interested to paradiseliving</h3>
          <p>The sun collectors, shall provide the electricity of the social areas of the site and shall do its part for protecting the environment.</p>
          </div>
         
      </div>
      
    </div>
    
  </div>
  
</section>
          {/* schedule visit */}
        <section class="recent-posts">
  <div class="container">
    <div class="row">
      <div class="col-12 wow fadeInUp">
        <h4><span>paradiseliving</span> Living Spaces</h4> </div>
     
      <div class="col-lg-4 wow fadeInUp" data-wow-delay="0s">
        <div class="post-box">
          <figure> <img src={rnew01} alt="Image"/> </figure>
          <span>24, September 2019</span>
          <h6><a >50th Anniversary of the Turner School of Construction Management </a></h6>
          
        </div>
        
      </div>
      
      <div class="col-lg-4 wow fadeInUp" data-wow-delay="0.10s">
        <div class="post-box">
          <figure> <img src={rnew02} alt="Image"/> </figure>
          <span>06, November 2019</span>
          <h6><a >The Center for Construction Research and Training to Receive 2019 Award</a></h6>
         
        </div>
        
      </div>
     
      <div class="col-lg-4 wow fadeInUp" data-wow-delay="0.20s">
        <div class="post-box">
          <figure> <img src={rnew03} alt="Image"/> </figure>
          <span>31, April 2019</span>
          <h6><a >Henry C. Turner Prize for Innovation in Construction Company</a></h6>
          
        </div>
       
      </div>
       
    </div>
   
  </div>
 
</section>


          {/* video */}
            <section className="property-customization">
  <div className="video-bg">
   
    <video loop autoplay muted controls >
      <source src={video1} type="video/mp4"/>
     </video>
   
  </div>
  
  <div className="container">
    <div className="row">
      <div className="col-12 wow fadeInUp"> 
        <h4><span>paradiseliving</span> Living Spaces</h4>
        <h3>Are you interested to paradiseliving</h3>
      </div>
      
      <div className="col-lg-2 col-md-4 col-sm-6 col-6 wow fadeInUp" data-wow-delay="0s">
        <figure data-toggle="tooltip" data-placement="top" title="The smaller male cones release pollen, which fertilizes"> <img src={icon1} alt="Image"/>
          <figcaption>Water Taps</figcaption>
        </figure>
      </div>
   
      <div className="col-lg-2 col-md-4 col-sm-6 col-6 wow fadeInUp" data-wow-delay="0.05s">
        <figure data-toggle="tooltip" data-placement="top" title="The smaller male cones release pollen, which fertilizes"> <img src={icon2} alt="Image"/>
          <figcaption>Furniture</figcaption>
        </figure>
      </div>
      
      <div className="col-lg-2 col-md-4 col-sm-6 col-6 wow fadeInUp" data-wow-delay="0.10s">
        <figure data-toggle="tooltip" data-placement="top" title="The smaller male cones release pollen, which fertilizes"> <img src={icon3} alt="Image"/>
          <figcaption>Electricity</figcaption>
        </figure>
      </div>
      
      <div className="col-lg-2 col-md-4 col-sm-6 col-6 wow fadeInUp" data-wow-delay="0.15s">
        <figure data-toggle="tooltip" data-placement="top" title="The smaller male cones release pollen, which fertilizes"> <img src={icon4} alt="Image"/>
          <figcaption>Wood Edition</figcaption>
        </figure>
      </div>
     
      <div className="col-lg-2 col-md-4 col-sm-6 col-6 wow fadeInUp" data-wow-delay="0.20s">
        <figure data-toggle="tooltip" data-placement="top" title="The smaller male cones release pollen, which fertilizes"> <img src={icon5} alt="Image"/>
          <figcaption>Ceramics</figcaption>
        </figure>
      </div>
      
      <div className="col-lg-2 col-md-4 col-sm-6 col-6 wow fadeInUp" data-wow-delay="0.25s">
        <figure data-toggle="tooltip" data-placement="top" title="The smaller male cones release pollen, which fertilizes"> <img src={icon6} alt="Image"/>
          <figcaption>Pipelines</figcaption>
        </figure>
      </div>
      
      <div className="col-lg-2 col-md-4 col-sm-6 col-6 wow fadeInUp" data-wow-delay="0s">
        <figure data-toggle="tooltip" data-placement="top" title="The smaller male cones release pollen, which fertilizes"> <img src={icon7} alt="Image"/>
          <figcaption>Cimento</figcaption>
        </figure>
      </div>
      
      <div className="col-lg-2 col-md-4 col-sm-6 col-6 wow fadeInUp" data-wow-delay="0.05s">
        <figure data-toggle="tooltip" data-placement="top" title="The smaller male cones release pollen, which fertilizes"> <img src={icon8} alt="Image"/>
          <figcaption>Hummer</figcaption>
        </figure>
      </div>
      
      <div className="col-lg-2 col-md-4 col-sm-6 col-6 wow fadeInUp" data-wow-delay="0.10s">
        <figure data-toggle="tooltip" data-placement="top" title="The smaller male cones release pollen, which fertilizes"> <img src={icon9} alt="Image"/>
          <figcaption>Digging</figcaption>
        </figure>
      </div>
      
      <div className="col-lg-2 col-md-4 col-sm-6 col-6 wow fadeInUp" data-wow-delay="0.15s">
        <figure data-toggle="tooltip" data-placement="top" title="The smaller male cones release pollen, which fertilizes"> <img src={icon10} alt="Image"/>
          <figcaption>Raiser</figcaption>
        </figure>
      </div>
      
      <div className="col-lg-2 col-md-4 col-sm-6 col-6 wow fadeInUp" data-wow-delay="0.20s">
        <figure data-toggle="tooltip" data-placement="top" title="The smaller male cones release pollen, which fertilizes"> <img src={icon11} alt="Image"/>
          <figcaption>Screwsrive</figcaption>
        </figure>
      </div>
     
      <div className="col-lg-2 col-md-4 col-sm-6 col-6 wow fadeInUp" data-wow-delay="0.25s">
        <figure data-toggle="tooltip" data-placement="top" title="The smaller male cones release pollen, which fertilizes"> <img src={icon12} alt="Image"/>
          <figcaption>Blueprint</figcaption>
        </figure>
      </div>
      
    </div>
    
  </div>
  
</section>
<Footer/>
        </div>
    )
}

export default PageVideo
