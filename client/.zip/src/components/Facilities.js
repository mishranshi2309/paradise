import React from 'react'
import Footer from './Footer'
import '../components/styles/css/style.css';
import servicon from './styles/images/services-icon01.png';
import servicon2 from './styles/images/services-icon02.png';
import servicon3 from './styles/images/services-icon03.png';
import servicon4 from './styles/images/services-icon04.png';
import servicon5 from './styles/images/services-icon05.png';
import servicon6 from './styles/images/services-icon06.png';
import servicon7 from './styles/images/services-icon07.png';
import servicon8 from './styles/images/services-icon08.png';
import servicon9 from './styles/images/services-icon09.png';
import CommonMenu from './CommonMenu';

function Facilities() {

	
    return (
        <div>
			<CommonMenu/>
			<header class="page-header" data-background="#" data-stellar-background-ratio="1.15">
	<div class="container">
		<h1>Facilities</h1>
		<p>Make yourself feel comfortable in luxury </p>
		  <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="#">Start</a></li>
    <li class="breadcrumb-item active" style={{color:'white'}}>Facilities</li>
  </ol>
	</div>
	
</header>
           <section class="facilities">
  <div class="container">
    <div class="row">
    	<div class="col-lg-4 col-md-6">
    	<figure>
    		<img src={servicon} alt="Image"/>
    		<figcaption>
    		<h5>Flexible Transportation</h5>
    		<p>Make yourself feel comfortable in luxury </p>
    		</figcaption>
    		</figure>
    	</div>
    	<div class="col-lg-4 col-md-6">
    		<figure>
    		<img src={servicon2} alt="Image"/>
    		<figcaption>
    		<h5>Friendly Living Spaces</h5>
    		<p>Make yourself feel comfortable in luxury </p>
    		</figcaption>
    		</figure>
    	</div>
    	<div class="col-lg-4 col-md-6">
    		<figure>
    		<img src={servicon3} alt="Image"/>
    		<figcaption>
    		<h5>Maximum Life of Quality</h5>
    		<p>Make yourself feel comfortable in luxury </p>
    		</figcaption>
    		</figure>
    	</div>
    	<div class="col-lg-4 col-md-6">
    		<figure>
    		<img src={servicon4} alt="Image"/>
    		<figcaption>
    		<h5>Recycling Solar Energy </h5>
    		<p>Make yourself feel comfortable in luxury </p>
    		</figcaption>
    		</figure>
    	</div>
    	<div class="col-lg-4 col-md-6">
    		<figure>
    		<img src={servicon5} alt="Image"/>
    		<figcaption>
    		<h5>Amazing Flat Structure</h5>
    		<p>Make yourself feel comfortable in luxury </p>
    		</figcaption>
    		</figure>
    	</div>
    	<div class="col-lg-4 col-md-6">
    		<figure>
    		<img src={servicon6} alt="Image"/>
    		<figcaption>
    		<h5>Unique Playground Area</h5>
    		<p>Make yourself feel comfortable in luxury </p>
    		</figcaption>
    		</figure>
    	</div>
    	<div class="col-lg-4 col-md-6">
    	<figure>
    		<img src={servicon7} alt="Image"/>
    		<figcaption>
    		<h5>Flexible Transportation</h5>
    		<p>Make yourself feel comfortable in luxury </p>
    		</figcaption>
    		</figure>
    	</div>
    	<div class="col-lg-4 col-md-6">
    		<figure>
    		<img src={servicon8} alt="Image"/>
    		<figcaption>
    		<h5>Friendly Living Spaces</h5>
    		<p>Make yourself feel comfortable in luxury </p>
    		</figcaption>
    		</figure>
    	</div>
    <div class="col-lg-4 col-md-6">
    		<figure>
    		<img src={servicon9} alt="Image"/>
    		<figcaption>
    		<h5>Maximum Life of Quality</h5>
    		<p>Make yourself feel comfortable in luxury </p>
    		</figcaption>
    		</figure>
    	</div>
		</div>
  </div>
  
</section>
<Footer/>
        </div>
    )
}

export default Facilities
