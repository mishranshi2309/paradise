import React from "react";
import axios from "axios";
import "../components/styles/js/main_signup.js";
import "../components/styles/css/style.css";
import "../components/styles/css/style_signup.css";
import avtar from "../components/styles/images/signuplogin/loginavatar.png";
import signupimg from "../components/styles/images/signuplogin/img1.svg";
import { Link } from "react-router-dom";
import CommonMenu from "./CommonMenu";
import Footer from "./Footer";
import PORT from "./ENV";
import swal from "sweetalert";
class Signup extends React.Component {
  state = {
    username: "",
    password: "",
    email: "",
  };
  handleChange = (e) => {
    this.setState({ [e.target.name]: e.target.value });
    console.log(this.state);
  };
  handleSubmit = async () => {
    // axios.post(`http://localhost:${PORT}/signup`, this.state)
    //     .then(res=>{
    //         console.log(res);
    //     });
    const res = await fetch(`http://localhost:${PORT}/signup`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      success: function (response) {
        console.log("this is response " + response);
        console.log("this is response status " + JSON.parse(response));
        
      },
      body: JSON.stringify({
        username: this.state.username,
        email: this.state.email,
        password: this.state.password,
        role: this.state.role
      }),
    });

    if (res.status === 200) {
      swal("Successfully Registered!!").then(() => {
        window.location = "/login";
        // if(username === 'admin'){
        //     window.location ="/dashboard";
        // }
        // else if(localStorage.getItem('property')){
        //     const goToPage = localStorage.getItem('property');
        //     localStorage.removeItem('property');
        //     window.location = goToPage;
        // }
        // else{
        //     window.location = "/login";
        // }
      });
    } else {
      window.alert("This Username Already Exist !!");
      swal("This Username Already Exist !!").then(() => {
        window.location = "/signup";
      });
    }
  };
  render() {
    return (
      <div>
        <CommonMenu />
        <header
          className="page-header"
          data-background="images/slide01.jpg"
          data-stellar-background-ratio="1.15"
        >
          <div className="container" style={{ marginTop: "-30vh" }}>
            <h1>SIGN UP</h1>
            <p>Make yourself feel comfortable in luxury </p>
            <ol className="breadcrumb mt-5">
              <li className="breadcrumb-item">
                <a href="#">Start</a>
              </li>
              <li className="breadcrumb-item active" style={{ color: "white" }}>
                signup
              </li>
            </ol>
          </div>
        </header>
        <center>
          <div className="form-container">
            <div className="img">
              <img src={signupimg} />
            </div>
            <div className="login-container">
              <form onSubmit={() => this.handleSubmit()}>
                <img src={avtar} className="avatar" />
                <h2>Sign Up</h2>
                <div className="input-div one">
                  <div className="i">
                    <i className="fa fa-user-circle"></i>
                  </div>
                  <div>
                    <input
                      type="text"
                      placeholder="Username"
                      className="input"
                      name="username"
                      id="username"
                      autocomplete="off"
                      value={this.state.username}
                      onChange={(e) => this.handleChange(e)}
                      required
                    />
                  </div>
                </div>
                <div className="input-div one">
                  <div className="i">
                    <i className="fa fa-envelope"></i>
                  </div>
                  <div>
                    <input
                      type="email"
                      placeholder="Email"
                      className="input"
                      name="email"
                      id="email"
                      value={this.state.email}
                      onChange={(e) => this.handleChange(e)}
                      autocomplete="off"
                      required
                    />
                  </div>
                </div>
                <div className="input-div one">
                  <div className="i">
                    <i className="fa fa-lock"></i>
                  </div>
                  <div>
                    <input
                      type="password"
                      placeholder="Password"
                      className="input"
                      name="password"
                      id="password"
                      value={this.state.password}
                      onChange={(e) => this.handleChange(e)}
                      autocomplete="off"
                      required
                    />
                  </div>
                  <div>
                    <select name="role" onChange={e=>this.handleChange(e)}>
                      <option disabled>Select Role</option>
                      <option value="Customer">Customer</option>
                      <option value="Agent">Agent</option>
                    </select>
                  </div>
                </div>
                <Link to="/login">
                  <a>Already have account? Login</a>
                </Link>
                <center>
                  <input type="submit" className="button" value="Signup" />
                </center>
              </form>
            </div>
          </div>
        </center>
        <Footer />
      </div>
    );
  }
}

export default Signup;
