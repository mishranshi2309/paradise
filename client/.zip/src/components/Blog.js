import React from 'react'
import CommonMenu from './CommonMenu';
import Footer from './Footer';
import './blog_styles/style.css';
import './blog_styles/responsive.css';
import Blog1 from './blog_styles/Blog1.jpg';
import Blog2 from './blog_styles/Blog2.jpg';
import Blog3 from './blog_styles/Blog3.jpg';
import Blog4 from './blog_styles/Blog4.jpg';
import Blog5 from './blog_styles/Blog5.jpg';
import Blog6 from './blog_styles/Blog6.jpg';
import PORT from './ENV';
// import './blog_styles/bootstrap.min.css';
function Blog() {
    return (
        <div>
            <CommonMenu/>
			<header class="page-header" data-background="images/slide01.jpg" data-stellar-background-ratio="1.15">
	<div class="container">
		<h1>Blog</h1>
		<p>Make yourself feel comfortable in luxury </p>
		  <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="#">Start</a></li>
    <li class="breadcrumb-item active" style={{color:'white'}}>Contact</li>
  </ol>
	</div>
</header>
            <section class="full_project_area"  style={{marginBottom: 20}}>
				<div class="container">
					<div class="blog_ms_inner row">
						<div class="col-lg-4 col-sm-6 news">
							<div class="blog_g_item">
								<div class="press_img_item">
									<div class="press_img">
										<img class="img-fluid" src={Blog1} style={{height:350,width:400}} alt=""/>
									</div>
									<div class="date">
										<a href="">august 19, 2018</a>
										<i class="ion-record"></i>
										<a href="">news</a>
									</div>
									<a href=""><h4>Enlightening lives under awesome survillence</h4></a>
									
								</div>
							</div>
						</div>
						<div class="col-lg-4 col-sm-6 news insp event">
							<div class="blog_g_item">
								<div class="press_img_item">
									<div class="press_img">
										<img class="img-fluid" src={Blog2} style={{height:350,width:400}} alt=""/>
									</div>
									<div class="date">
										<a href="">september 01, 2020</a>
										<i class="ion-record"></i>
										<a href="">news</a>
									</div>
									<a href=""><h4>Architecture should speak of its time and place, but yearn for timelessness</h4></a>
									
								</div>
							</div>
						</div>
						<div class="col-lg-4 col-sm-6 news insp event">
							<div class="blog_g_item">
								<div class="press_img_item">
									<div class="press_img">
										<img class="img-fluid" src={Blog3} style={{height:350,width:400}} alt=""/>
									</div>
									<div class="date">
										<a href="">june 10, 2018</a>
										<i class="ion-record"></i>
										<a href="">news</a>
									</div>
									<a href=""><h4>There are no straight lines or sharp corners in nature. ...</h4></a>
									
								</div>
							</div>
						</div>
						<div class="col-lg-4 col-sm-6 news insp event">
							<div class="blog_g_item">
								<div class="press_img_item">
									<div class="press_img">
										<img class="img-fluid" src={Blog4} style={{height:350,width:400}} alt=""/>
									</div>
									<div class="date">
										<a href="">may 19, 2021</a>
										<i class="ion-record"></i>
										<a href="">news</a>
									</div>
									<a href=""><h4>Whatever good things we build end up building us.</h4></a>
									
								</div>
							</div>
						</div>
                        <div class="col-lg-4 col-sm-6 news event">
							<div class="blog_g_item">
								<div class="press_img_item">
									<div class="press_img">
										<img class="img-fluid" src={Blog6} style={{height:350,width:400}} alt=""/>
									</div>
									<div class="date">
										<a href="">august 19, 2018</a>
										<i class="ion-record"></i>
										<a href="">news</a>
									</div>
									<a href=""><h4>Architecture is basically a container of something. I hope they will enjoy not so much the teacup, but the tea.</h4></a>
									
								</div>
							</div>
						</div>
						<div class="col-lg-4 col-sm-6 news insp">
							<div class="blog_g_item">
								<div class="press_img_item">
									<div class="press_img">
										<img class="img-fluid" src={Blog5} style={{height:350,width:400}} alt=""/>
									</div>
									<div class="date">
										<a href="">june 10, 2021</a>
										<i class="ion-record"></i>
										<a href="">news</a>
									</div>
									<a href=""><h4>We shape our buildings: thereafter they shape us</h4></a>
									
								</div>
							</div>
						</div>
						
						
						
					</div>
				</div>
			</section>
            <Footer/>
        </div>
        
    )
}

export default Blog
