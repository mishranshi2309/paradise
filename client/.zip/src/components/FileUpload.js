import React from 'react';
import axios from 'axios';
import '../components/styles/js/main_signup.js'
import '../components/styles/css/style.css';
import '../components/styles/css/style_signup.css';
import avtar from '../components/styles/images/signuplogin/loginavatar.png'
import signupimg from '../components/styles/images/signuplogin/img1.svg'
import { Link } from 'react-router-dom';
import CommonMenu from './CommonMenu';
import PORT from './ENV';
class Signup extends React.Component {
    state={
        cate:'',
        info:'',
        status:'',
        state:'',
        district:'',
        city:'',
        costpersq:'',
        address:'',
        area:'',
        myfile:''
        
    }
     handleChange=(e)=>{
        this.setState({[e.target.name]:e.target.value})
        console.log("stateh:", this.state);
    }
    handleFileChange=(e)=>{
      
      const files = e.target.files;
      const formData = new FormData();
      console.log(files);
       formData.append('myfile', files[0]);
        console.log(formData);
      this.setState({[e.target.name]:files[0]});
      console.log("state",this.state);   // this console is giving proper data . 
    }
     handleSubmit = () =>{
        axios.post(`http://localhost:${PORT}/uploadfile`, this.state)
        .then(res=>{
            console.log("successfully sent");
            this.setState({cate:'',
            info:'',
            status:'',
            state:'',
            district:'',
            city:'',
            costpersq:'',
            address:'',
            area:'',
            myfile:''
        })
        });
      window.location='/uploadfile';
    }
    render(){
    return (
        <div>
            <CommonMenu/>
                <header className="page-header" data-background="images/slide01.jpg" data-stellar-background-ratio="1.15">
                    <div className="container">
                        <h1>upload property</h1>
                        <p>Make yourself feel comfortable in luxury </p>
                        <ol className="breadcrumb">
                            <li className="breadcrumb-item"><a href="#">Start</a></li>
                            <li className="breadcrumb-item active" aria-current="page">signup</li>
                        </ol>
                    </div>
                </header>
        <center>
        <div className="form-container">
        <div className="img">
            <img src={signupimg}/>
        </div>
        <div className="login-container">
            <form onSubmit={()=>this.handleSubmit()} encType="multipart/form-data">
                <img src={avtar} className="avatar"/>
                <h2>upload property</h2>
                <div>
                    <div>              
                        <input type="text" placeholder="cate" name="cate" id="cate" autocomplete="off" value={this.state.cate} onChange={(e)=>this.handleChange(e)} required/>
                    </div>
                </div>
                <div>
                    <div>
                        <input type="text" placeholder="status" name="status" id="status" value={this.state.status} onChange={(e)=>this.handleChange(e)} autocomplete="off" required/>
                    </div>
                </div>
                <div>
                    <div>
                        <input type="text" placeholder="info" name="info" id="info" value={this.state.info} onChange={(e)=>this.handleChange(e)} autocomplete="off" required/>
                    </div>
                </div>
                <div>
                    <div>
                        <input type="text" placeholder="state" name="state" id="state" value={this.state.state} onChange={(e)=>this.handleChange(e)} autocomplete="off" required/>
                    </div>
                </div>
                <div>
                    <div>
                        <input type="text" placeholder="district" name="district" id="district" value={this.state.district} onChange={(e)=>this.handleChange(e)} autocomplete="off" required/>
                    </div>
                </div>
                <div>
                    <div>
                        <input type="text" placeholder="city" name="city" id="city" value={this.state.city} onChange={(e)=>this.handleChange(e)} autocomplete="off" required/>
                    </div>
                </div>
                <div>
                    <div>
                        <input type="text" placeholder="cost per square" name="costpersq" id="costpersq" value={this.state.costpersq} onChange={(e)=>this.handleChange(e)} autocomplete="off" required/>
                    </div>
                </div>
                <div>
                    <div>
                        <input type="text" placeholder="address" name="address" id="address" value={this.state.address} onChange={(e)=>this.handleChange(e)} autocomplete="off" required/>
                    </div>
                </div>
                <div>
                    <div>
                        <input type="text" placeholder="area" name="area" id="area" value={this.state.area} onChange={(e)=>this.handleChange(e)} autocomplete="off" required/>
                    </div>
                </div>
                <div>
                    <div>
                        <input type="file" name="myfile" onChange={(e)=>this.handleFileChange(e)}  required/>
                    </div>
                </div>
                <center>
                    <input type="submit" className="button" value="upload"/>
                </center>
            </form>
        </div>
    </div></center>
        </div>
    )
    }
}

export default Signup
