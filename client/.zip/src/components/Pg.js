import React, { useState, useEffect } from "react";
import axios from "axios";
import author from "./styles/images/author01.jpg";
import "../components/styles/js/main_signup.js";
import "../components/styles/css/style.css";
import "../components/styles/css/style_property.css";
import "../components/styles/css/style_signup.css";
import { NavLink, useHistory, Link } from "react-router-dom";
import image1 from "../components/styles/images/blog01.jpg";
import slide02 from '../components/styles/images/slide02.jpg';
import CommonMenu from "./CommonMenu";
import Footer from "./Footer";
import swal from "sweetalert";
import PORT from './ENV';
function Pg() {
    const [todos, setTodos] = useState();

    const handleWp = (phone, propertyname) => {
      if (localStorage.getItem("paradiseLogin") !== null) {
        const msg = "Hii , Interested in your property at " + propertyname;
        window.open(`https://wa.me/+91${phone}?text=` + msg, "_blank");
      } else {
        const action = swal({
          title: 'Please Login First',
          input: 'text',
          buttons: {
            cancel: true,
            confirm: true,
          },
          showCancelButton: true,
          closeOnConfirm: false,
          closeOnCancel: true
        }).then((res)=>{
          if(res){
            const pageLocation  = window.location.href;
            localStorage.setItem("property", window.location.href);
            window.location = "/login";
          }
        });
        // window.alert("Please login");
        // window.location= "/login";
      }
    };
  
    const handleCall = (phone) => {
      if (localStorage.getItem("paradiseLogin") !== null) {
        swal("Get in touch at : +91" + phone);
      } else {
        const action = swal({
          title: 'Please Login First',
          input: 'text',
          buttons: {
            cancel: true,
            confirm: true,
          },
          showCancelButton: true,
          closeOnConfirm: false,
          closeOnCancel: true
        }).then((res)=>{
          if(res){
            const pageLocation  = window.location.href;
            localStorage.setItem("property", window.location.href);
            window.location = "/login";
          }
        });
        // window.alert("Please login");
        // window.location= "/login";
      }
    };
    useEffect(() => {
      var request = new XMLHttpRequest();
      request.onreadystatechange = function () {
        if (request.readyState == 4 && request.status == 200) {
          const response = JSON.parse(request.response);
          setTodos(response);
        }
      };
      request.open("GET", `http://localhost:${PORT}/pg`, true);
      request.send();
    }, []);
  
    useEffect(() => {
      console.log(todos);
    }, [todos]);
    return (
      <div>
              <CommonMenu/>
  
              <header class="page-header" data-background={slide02} data-stellar-background-ratio="1.15">
                  <div class="container">
                      <h1>Paying Guest</h1>
                      <p>Get details about property based on your Requierment..</p>
                      <ol class="breadcrumb">
                          <li class="breadcrumb-item"><a>Home</a></li>
                          <li class="breadcrumb-item" style={{color:'white'}}>Property</li>
                      </ol>
                  </div>
              </header>
              <div className="container">
                  <h3>SELECT PROPERTY</h3> <hr/>
                  <div className="mx-auto">
                  <div className="filter_btn"><Link to="/bunglow"><a>Bunglow</a></Link></div>
                      <div className="filter_btn"><Link to="/rent"><a>Rent</a></Link></div>
                      <div className="filter_btn"><Link to="/pg"><a>Paying Guest</a></Link></div>
                      <div className="filter_btn"><Link to="/flat"><a>Flat</a></Link></div>
                  </div>
              </div>
  
            
               <section class="bunglow_details" >
               {todos &&
              todos.map((todo) => (
                <div class="container-fluid">
                      <div class="row">
                          <div class="col-lg-12 col-md-6" >
                              <figure>
                                  <div className="row bg">
                                      <div className="col-3" >
                                          <img src={image1} alt="Image"/>
                                      </div>
                                      <div className="col-4">
                                          <p><b>Rs.{todo.area * todo.costpersq}/-</b></p>
                                          <h5>Flexible Transportation</h5>
                                          <p> <b> <i class="fa fa-map-pin" aria-hidden="true"></i> Location:</b>{todo.address}, {todo.city}, {todo.state}</p>
                                      </div>
                                      <div className="col-2">
                                          <h3>Quality</h3>
                                          <p class="mt-4">
                                              <ul class="nav">
                                                  
                                                  <li class="nav-item">
                                                      <p class="nav-link" href="#">
                                                      {todo.houseFacing}<br/>House Facing
                                                      </p>
                                                  </li>
                                                  <li class="nav-item">
                                                      <p class="nav-link" href="#">
                                                          {todo.floor}<br/>floor
                                                      </p>
                                                  </li>
                                                  <li class="nav-item">
                                                      <p class="nav-link" href="#">
                                                          {todo.area}<br/>square feet
                                                      </p>
                                                  </li>
                                                  <li class="nav-item">
                                                      <p class="nav-link" href="#">
                                                      {todo.bhk}<br/>Size
                                                          {/* {todo.houseFacing}<br/>House Facing */}
                                                      </p>
                                                  </li>
                                              </ul>
                                          </p>
                                      </div>
                                      <div className="col-2 mt-3 ml-5">
                                         <Link to={{
                                          pathname:'/detailProperty',
                                          state: { number: todo.contactNumber,
                                                    address: todo.address,
                                                    area: todo.area,
                                                    category: todo.cate,
                                                    city: todo.city,
                                                    costpersq: todo.costpersq,
                                                  district:todo.district,
                                                info: todo.info,
                                              state: todo.state,
                                             status: todo.status,
                                            extrafacility: todo.extrafacility,
                                            bhk:todo.bhk,
                                            floor: todo.floor,
                                            sellerName: todo.sellerName,
                                            houseFacing: todo.houseFacing
                                          }
                                        }}> <p className="contact_btn">Read more</p></Link><br/>
                                          <p className="contact_btn" onClick={() => {
                        handleWp(todo.contactNumber, todo.address);
                      }}>Whatsapp</p>
                                          <p className="contact_btn" onClick={() => {
                        handleCall(todo.contactNumber);
                      }}>contact</p>
                                      </div>
                                  </div>
                              </figure>
                          </div>
                      </div>
                  </div>
              ))}
                  
              </section>
              <Footer/>
          </div>
    );
}

export default Pg
