import React, { useState } from "react";
import { useLocation } from "react-router-dom";
import "./styles/js/main_signup.js";
import "../components/styles/css/style.css";
import "../components/styles/css/style_property.css";
import "../components/styles/css/style_signup.css";
import { NavLink, useHistory, Link } from "react-router-dom";
import slide01 from "../components/styles/images/slide01.jpg";
import blog02 from "../components/styles/images/blog01.jpg";
import CommonMenu from "./CommonMenu";
import Footer from "./Footer";
import swal from "sweetalert";
import swal2 from "sweetalert2";
import Bunglow from "./Bunglow";
import "bootstrap/dist/css/bootstrap.min.css";
import PORT from "./ENV";
import {Modal, Button, Form} from 'react-bootstrap';
function PropertyDetail(props) {
  const location = useLocation();
  const history = useHistory();

  // const [usermail, setUsermail] = useState("");
  // const [date, setDate] = useState("");
  // const [time, setTime] = useState("");
  let obj = location.state;
  console.log(obj);
  //const recmail = location.state.agentmail;


  const [password, setPassword] = useState('')

  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  const [mailid, setMailId] = useState('')
  const [inviteDetails, setInviteDetails] = useState({usermail:"", date:"", time:""})
  const handleInviteSubmit = () =>{
    
    handleClose();
    const res = fetch(`http://localhost:${PORT}/videocall`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      success: function (response) {
        console.log("this is response " + response);

        console.log("this is response status " + JSON.parse(response));
      },
      body: JSON.stringify({mailid,password,...inviteDetails}),
    }).then(()=>{
      console.log("------------");
      history.goBack();
    })

    //
  }


  const handleChange = (e) =>{
    let name = e.target.name;
    let value = e.target.value;
    inviteDetails[name] = value;
    setInviteDetails(inviteDetails);
    setPassword(btoa(inviteDetails.usermail))
    console.log(password);
  }
  const handleVideoMail = async (mailid) => {
    handleShow();
    setMailId(mailid);
    // const { value: email } = await swal2.fire({
    //   title: "Input email address",
    //   input: "email",
    //   inputLabel: "Your email address",
    //   inputPlaceholder: "Enter your email address",
    // });

    // if (email) {
    //   setUsermail(email);
    //   swal2.fire(`Entered email: ${email}`);
    // }

    // const { value: text } = await swal2.fire({
    //   title: "Input email address",
    //   input: "text",
    //   inputLabel: "Your meet date",
    //   inputPlaceholder: "dd/mm/yy",
    // });

    // if (text) {
    //   setDate(text);
    //   swal2.fire(`Entered date: ${text}`);
    // }

    // const { value: time } = await swal2.fire({
    //   title: "Input time",
    //   input: "text",
    //   inputLabel: "Your meet time",
    //   inputPlaceholder: "hh:mm",
    // });

    // if (time) {
    //   setTime(time);
    //   swal2.fire(`Entered time: ${time}`);
    // }
    
  };

  const handleVideo = () => {
    window.location = "https://paradisevideo.netlify.app/";
    // location.url("/https://paradisevchat.jalsatourism.com/");
  };
  return (
    <div>
      <CommonMenu />
      <Modal show={show} >
        <Modal.Header >
          <Modal.Title>Send Invite</Modal.Title>
        </Modal.Header>
        <Form onSubmit={handleInviteSubmit}>
        <Modal.Body>

            
        <Form.Group controlId="formBasicEmail">
          <Form.Control type="email" name="usermail" placeholder="Enter email" onChange={handleChange}/>
        </Form.Group>

        <Form.Group controlId="formBasicPassword">
          <Form.Control type="date" name="date" placeholder="Date" onChange={handleChange}/>
        </Form.Group>
        
        <Form.Group controlId="formBasicPassword">
          <Form.Control type="time" name="time" placeholder="Time" onChange={handleChange}/>
        </Form.Group>
        
    

        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
          <Button variant="primary" type="submit">
          Submit
        </Button>
        </Modal.Footer>
        </Form>
      </Modal>
      <header
        class="page-header"
        data-background={slide01}
        data-stellar-background-ratio="1.15"
      >
        <div class="container">
          <h1>Property Detail</h1>
          <p>Let's know more..</p>
          <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a>Home</a>
            </li>
            <li class="breadcrumb-item" style={{ color: "white" }}>
              Property
            </li>
          </ol>
        </div>
      </header>
      <div className="container">
        <div class="row">
          <div className="container">
            <h3>SELECT PROPERTY</h3> <hr />
            <div className="mx-auto">
              <div className="filter_btn">
                <Link to="/bunglow">
                  <a>Bunglow</a>
                </Link>
              </div>
              <div className="filter_btn">
                <Link to="/rent">
                  <a>Rent</a>
                </Link>
              </div>
              <div className="filter_btn">
                <Link to="/pg">
                  <a>Paying Guest</a>
                </Link>
              </div>
              <div className="filter_btn">
                <Link to="/flat">
                  <a>Flat</a>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="container mt-5">
        <div class="row mt-5">
          <div class="col-8">
            <img src={blog02} alt="img" srcset="" />
          </div>
          <div class="col-4">
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3720.250366898258!2d72.806969514886!3d21.182210885915456!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be04f0743aeb119%3A0xb8e4a4f681fadc30!2sSCET%20CANTEEN!5e0!3m2!1sen!2sin!4v1624223132951!5m2!1sen!2sin"
              width="400"
              height="480"
              style={{ border: 0 }}
              allowfullscreen=""
              loading="lazy"
            ></iframe>
          </div>
        </div>
        <div class="row">
          <div class="col-lg-8 col-md-12">
            <table class="table">
              <thead>
                <tr>
                  <th scope="row">Details about property</th>
                </tr>
                <tr>
                  <td colspan="2">
                    Enjoy your living standard with Paradise Living . We provide
                    first class build in , raw, ready to move , customize house
                    within your pocket budget.
                  </td>
                </tr>
              </thead>
              <tbody>
                {obj && Object.keys(obj).map((data) => (
                  <tr>
                    <th>{data}</th>
                    <td>{obj[data]}</td>
                  </tr>
                ))}
                <button
                  className="vcm"
                  onClick={() => {
                    handleVideoMail(location.state.agentmail);
                  }}
                >
                  <img src="https://img.icons8.com/fluent/48/000000/apple-mail.png" />
                </button>
                <button className="vc" onClick={handleVideo}>
                  <img src="https://img.icons8.com/color/48/000000/zoom.png" />
                </button>
              </tbody>
            </table>
          </div>
        </div>
      </div>
      
      <Footer />
    </div>
  );
}

export default PropertyDetail;
