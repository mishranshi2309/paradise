import React,{useState} from 'react'
import axios from 'axios';
import PORT from './ENV';
function UploadProperty() {
    const[formData, setFormData]=useState('');
    const[info ,setInfo]=useState({
        name:'',
        image:''
    })
    const upload=({target:{files}}) =>{
            let data = new FormData();
            data.append('categoryImage', files[0])
            data.append('name', files.name)
            setFormData(data)
        }

    const handleSubmit = (e) =>{
        e.preventDefault();
        setInfo({
            image:'',
            name:''
        })
        axios.post(`http://localhost:${PORT}/api/category`, formData).then(
            res=>{
                setTimeout(()=>{
                    setInfo(res.data.category)
                },1000)
            }
        )
    }

    return (
        <div>
            <form onSubmit={handleSubmit}>
                <input type="file" />
                <br/>
                <button type="submit">Submit</button>
            </form>

            <img
            src = {`http://localhost:${PORT}/${info.image}`}
            style={{"width":"50%", "height":"50%"}}
            />

            <div>{info.name}</div>
        </div>
    )
}

export default UploadProperty
