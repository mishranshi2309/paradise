import logo from './logo.svg';
import './App.css';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';

import PageVideo from './components/PageVideo';
import {BrowserRouter as Router,Switch , Route} from 'react-router-dom';
import Bunglow from './components/Bunglow';
import Flat from './components/Flat';
import Pg from './components/Pg';
import Plot from './components/Plot';
import About from './components/About';
import Blog from './components/Blog';
import Facilities from './components/Facilities';
import Login from './components/Login';
import Signup from './components/Signup';
import Logindetails from './components/Logindetails';
import Logout from './components/Logout';
import FileUpload from './components/FileUpload';
import UploadProperty from './components/UploadProperty';
import PropertyDetail from './components/PropertyDetail';
import Dashboard from "./components/Dashboard/Home";
import PORT from './components/ENV';
function App() {
  return (
    <Router>
   
    <Switch>
      <Route exact path="/"><PageVideo/></Route>
      <Route exact path="/bunglow"><Bunglow/></Route>
      <Route exact path="/rent"><Plot/></Route>
      <Route exact path="/flat"><Flat/></Route>
      <Route exact path="/pg"><Pg/></Route>
      <Route exact path="/about"><About/></Route>
      <Route exact path="/blog"><Blog/></Route>
      <Route exact path="/facilities"><Facilities/></Route>
      <Route exact path="/login"><Login/></Route>
      <Route exact path="/signup"><Signup/></Route>
      <Route exact path="/ldetail"><Logindetails/></Route>
      <Route exact path="/upload"><FileUpload/></Route>
      <Route exact path="/uploadproperty"><UploadProperty/></Route>
      <Route exact path="/logout"><Logout/></Route>
      <Route exact path="/detailProperty"><PropertyDetail/></Route>
      <Route exact path="/dashboard"><Dashboard/></Route>
    </Switch>
    
    
    </Router>
  );
}

export default App;
